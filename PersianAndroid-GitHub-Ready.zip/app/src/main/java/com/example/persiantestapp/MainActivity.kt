package com.example.persiantestapp

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var rootBackground: View
    private lateinit var txtTitle: TextView
    private lateinit var txtContent: TextView

    private val prefs by lazy {
        getSharedPreferences("persian_test_app", MODE_PRIVATE)
    }

    private val imagePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )

                    prefs.edit()
                        .putString("background_uri", uri.toString())
                        .apply()

                    setBackgroundFromUri(uri)

                    Toast.makeText(
                        this,
                        "عکس پس‌زمینه با موفقیت تغییر کرد",
                        Toast.LENGTH_SHORT
                    ).show()

                } catch (e: Exception) {
                    Toast.makeText(
                        this,
                        "خطا در انتخاب تصویر",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rootBackground = findViewById(R.id.rootBackground)
        txtTitle = findViewById(R.id.txtTitle)
        txtContent = findViewById(R.id.txtContent)

        restoreSavedBackground()
        setupExpandableMenus()
        setupPages()
        setupBackgroundButtons()
    }

    private fun setupExpandableMenus() {
        val btnServices = findViewById<Button>(R.id.btnServices)
        val btnProducts = findViewById<Button>(R.id.btnProducts)
        val btnReports = findViewById<Button>(R.id.btnReports)

        val submenuServices = findViewById<LinearLayout>(R.id.submenuServices)
        val submenuProducts = findViewById<LinearLayout>(R.id.submenuProducts)
        val submenuReports = findViewById<LinearLayout>(R.id.submenuReports)

        btnServices.setOnClickListener {
            toggleSubmenu(submenuServices)
        }

        btnProducts.setOnClickListener {
            toggleSubmenu(submenuProducts)
        }

        btnReports.setOnClickListener {
            toggleSubmenu(submenuReports)
        }
    }

    private fun toggleSubmenu(submenu: LinearLayout) {
        submenu.visibility =
            if (submenu.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun setupPages() {
        findViewById<Button>(R.id.btnHome).setOnClickListener {
            showPage(
                "خانه",
                "به برنامه تست فارسی خوش آمدید. این نسخه برای آزمایش منو، زیرمنو و تغییر تصویر پس‌زمینه ساخته شده است."
            )
        }

        findViewById<Button>(R.id.btnWebDesign).setOnClickListener {
            showPage(
                "طراحی سایت",
                "در این قسمت می‌توانید بعداً اطلاعات مربوط به خدمات طراحی سایت را قرار دهید."
            )
        }

        findViewById<Button>(R.id.btnApplication).setOnClickListener {
            showPage(
                "اپلیکیشن",
                "این بخش برای معرفی خدمات یا امکانات اپلیکیشن در نظر گرفته شده است."
            )
        }

        findViewById<Button>(R.id.btnSupport).setOnClickListener {
            showPage(
                "پشتیبانی",
                "در نسخه اصلی می‌توان سیستم تیکت، تماس یا پشتیبانی آنلاین به این قسمت اضافه کرد."
            )
        }

        findViewById<Button>(R.id.btnProduct1).setOnClickListener {
            showPage("محصول شماره ۱", "اطلاعات محصول شماره ۱ در این بخش نمایش داده می‌شود.")
        }

        findViewById<Button>(R.id.btnProduct2).setOnClickListener {
            showPage("محصول شماره ۲", "اطلاعات محصول شماره ۲ در این بخش نمایش داده می‌شود.")
        }

        findViewById<Button>(R.id.btnProduct3).setOnClickListener {
            showPage("محصول شماره ۳", "اطلاعات محصول شماره ۳ در این بخش نمایش داده می‌شود.")
        }

        findViewById<Button>(R.id.btnDailyReport).setOnClickListener {
            showPage("گزارش روزانه", "نمونه محل نمایش گزارش‌های روزانه.")
        }

        findViewById<Button>(R.id.btnMonthlyReport).setOnClickListener {
            showPage("گزارش ماهانه", "نمونه محل نمایش گزارش‌های ماهانه.")
        }

        findViewById<Button>(R.id.btnYearlyReport).setOnClickListener {
            showPage("گزارش سالانه", "نمونه محل نمایش گزارش‌های سالانه.")
        }

        findViewById<Button>(R.id.btnAbout).setOnClickListener {
            showPage(
                "درباره ما",
                "این پروژه با Kotlin و Android Studio ساخته شده و برای توسعه یک اپلیکیشن فارسی قابل استفاده است."
            )
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            showPage(
                "تنظیمات",
                "برای تغییر عکس پس‌زمینه، دکمه «انتخاب عکس پس‌زمینه» را بزنید. تصویر انتخاب‌شده در تنظیمات برنامه ذخیره می‌شود."
            )
        }
    }

    private fun showPage(title: String, content: String) {
        txtTitle.text = title
        txtContent.text = content
    }

    private fun setupBackgroundButtons() {
        findViewById<Button>(R.id.btnChangeBackground).setOnClickListener {
            imagePicker.launch(arrayOf("image/*"))
        }

        findViewById<Button>(R.id.btnResetBackground).setOnClickListener {
            prefs.edit().remove("background_uri").apply()
            rootBackground.setBackgroundResource(R.drawable.default_background)

            Toast.makeText(
                this,
                "پس‌زمینه پیش‌فرض بازگردانی شد",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun restoreSavedBackground() {
        val savedUri = prefs.getString("background_uri", null)

        if (!savedUri.isNullOrEmpty()) {
            try {
                setBackgroundFromUri(Uri.parse(savedUri))
            } catch (_: Exception) {
                rootBackground.setBackgroundResource(R.drawable.default_background)
            }
        }
    }

    private fun setBackgroundFromUri(uri: Uri) {
        contentResolver.openInputStream(uri)?.use { stream ->
            val bitmap = BitmapFactory.decodeStream(stream)
            val drawable = BitmapDrawable(resources, bitmap)
            drawable.setBounds(0, 0, bitmap.width, bitmap.height)
            rootBackground.background = drawable
        }
    }
}
