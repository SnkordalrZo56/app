# برنامه تست فارسی اندروید

این Repository برای آپلود مستقیم در GitHub آماده شده و GitHub Actions می‌تواند فایل APK را به صورت خودکار بسازد.

## امکانات برنامه
- زبان فارسی و رابط راست‌چین
- چند منوی اصلی
- چند زیرمنوی باز و بسته‌شونده
- بخش خانه، خدمات، محصولات، گزارش‌ها، درباره ما و تنظیمات
- انتخاب عکس پس‌زمینه از گالری گوشی
- نگه‌داشتن عکس انتخاب‌شده برای دفعات بعد
- بازگردانی پس‌زمینه پیش‌فرض
- Kotlin + Android Studio

## ساخت خودکار APK در GitHub
Workflow پروژه در مسیر زیر قرار دارد:

`.github/workflows/build-apk.yml`

بعد از Push روی شاخه `main` یا `master`، GitHub Actions این مراحل را انجام می‌دهد:

- نصب Java 17
- نصب Gradle 8.9
- آماده‌سازی Android SDK 35
- اجرای `gradle :app:assembleDebug`
- قرار دادن APK در Artifacts

## دریافت APK
در GitHub وارد `Actions` شوید، آخرین اجرای `Build Android APK` را باز کنید و از قسمت `Artifacts` فایل `PersianTestApp-debug-apk` را دانلود کنید.

APK ساخته‌شده با نام `app-debug.apk` داخل Artifact قرار دارد.

## مشخصات پروژه
- Package: `com.example.persiantestapp`
- Minimum Android: API 24
- Compile/Target SDK: 35
- Android Gradle Plugin: 8.7.3
- Gradle used by GitHub Actions: 8.9
- Java: 17
